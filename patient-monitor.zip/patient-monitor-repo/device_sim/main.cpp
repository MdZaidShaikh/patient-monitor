#include "../common/protocol.h"

#include <arpa/inet.h>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <netinet/in.h>
#include <random>
#include <sys/socket.h>
#include <thread>
#include <unistd.h>

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <patient_id> [server_ip] [server_port]\n";
        return 1;
    }
    uint32_t patient_id = std::stoul(argv[1]);
    std::string server_ip = argc > 2 ? argv[2] : "127.0.0.1";
    int server_port = argc > 3 ? std::stoi(argv[3]) : 8080;

    std::mt19937 rng(std::random_device{}() + patient_id);
    std::normal_distribution<float> hr_jitter(0, 2.0);
    std::normal_distribution<float> bp_jitter(0, 3.0);
    std::normal_distribution<float> spo2_jitter(0, 0.5);
    std::uniform_real_distribution<float> anomaly_chance(0, 1);

    // Per-patient baseline so different patients look distinct on the dashboard.
    float base_hr = 65 + (patient_id % 5) * 5;      // 65-85
    float base_sys = 110 + (patient_id % 4) * 8;     // 110-134
    float base_dia = 70 + (patient_id % 3) * 5;      // 70-80
    float base_spo2 = 97;

    while (true) {
        int sock_fd = socket(AF_INET, SOCK_STREAM, 0);
        sockaddr_in server_addr{};
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(server_port);
        inet_pton(AF_INET, server_ip.c_str(), &server_addr.sin_addr);

        if (connect(sock_fd, (sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
            std::cerr << "[patient " << patient_id << "] connect failed, retrying in 2s...\n";
            close(sock_fd);
            std::this_thread::sleep_for(std::chrono::seconds(2));
            continue;
        }
        std::cout << "[patient " << patient_id << "] connected to " << server_ip << ":" << server_port << "\n";

        bool connection_alive = true;
        while (connection_alive) {
            ReadingMessage msg{};
            msg.patient_id = patient_id;
            msg.timestamp = static_cast<uint32_t>(std::time(nullptr));

            // ~2% chance per tick of injecting an anomaly so the alert engine
            // has something real to catch during a demo.
            bool anomaly = anomaly_chance(rng) < 0.02;

            if (anomaly) {
                // Pick one vital to spike/drop badly.
                int which = rng() % 3;
                msg.heart_rate = which == 0 ? (rng() % 2 ? 145 : 40) : base_hr + hr_jitter(rng);
                msg.spo2 = which == 1 ? 85 : base_spo2 + spo2_jitter(rng);
                msg.systolic_bp = which == 2 ? 165 : base_sys + bp_jitter(rng);
                msg.diastolic_bp = base_dia + bp_jitter(rng);
                std::cout << "[patient " << patient_id << "] *** injecting anomaly ***\n";
            } else {
                msg.heart_rate = base_hr + hr_jitter(rng);
                msg.spo2 = base_spo2 + spo2_jitter(rng);
                msg.systolic_bp = base_sys + bp_jitter(rng);
                msg.diastolic_bp = base_dia + bp_jitter(rng);
            }

            if (!send_reading(sock_fd, msg)) {
                std::cerr << "[patient " << patient_id << "] send failed, reconnecting...\n";
                connection_alive = false;
                break;
            }

            std::this_thread::sleep_for(std::chrono::milliseconds(1500));
        }
        close(sock_fd);
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
    return 0;
}
