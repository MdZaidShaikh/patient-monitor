#include "../common/protocol.h"
#include "alert_engine.h"
#include "db.h"
#include "safe_queue.h"
#include "shared_state.h"

#include <arpa/inet.h>
#include <atomic>
#include <csignal>
#include <cstring>
#include <iostream>
#include <netinet/in.h>
#include <sys/socket.h>
#include <thread>
#include <unistd.h>
#include <vector>

constexpr int PORT = 8080;
constexpr int NUM_WORKERS = 4;

SafeQueue<ReadingMessage> g_queue(1000);
SharedState g_state;
std::atomic<bool> g_running{true};
std::atomic<int> g_connected_clients{0};

void handle_signal(int) {
    g_running = false;
    g_queue.shutdown();
}

// One thread per connected device. Reads length-prefixed ReadingMessages in a
// loop and pushes each onto the shared queue. Exits when the client disconnects.
void client_handler(int client_fd, sockaddr_in client_addr) {
    char ip[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &client_addr.sin_addr, ip, INET_ADDRSTRLEN);
    g_connected_clients++;
    std::cout << "[+] Device connected from " << ip << " (active: " << g_connected_clients << ")\n";

    ReadingMessage msg;
    uint32_t last_patient_id = 0;
    while (g_running && recv_reading(client_fd, msg)) {
        last_patient_id = msg.patient_id;
        g_queue.push(msg);
    }

    if (last_patient_id != 0) g_state.mark_disconnected(last_patient_id);
    g_connected_clients--;
    std::cout << "[-] Device (patient " << last_patient_id << ") disconnected (active: "
              << g_connected_clients << ")\n";
    close(client_fd);
}

// Worker threads: pop readings off the queue, persist to SQLite, update the
// in-memory snapshot, run threshold checks. This is the consumer side of the
// producer-consumer pattern; client_handler threads are the producers.
void worker_loop(int worker_id, Database& db, AlertEngine& alerts) {
    ReadingMessage r;
    while (g_queue.pop(r)) {
        db.insert_reading(r);

        PatientSnapshot snap{r.patient_id, r.timestamp, r.heart_rate,
                              r.systolic_bp, r.diastolic_bp, r.spo2, true};
        g_state.update_snapshot(snap);

        alerts.check(r);
    }
    std::cout << "[worker " << worker_id << "] shutting down\n";
}

int main() {
    std::cout << std::unitbuf; // flush after every << so redirected logs aren't buffered away
    signal(SIGINT, handle_signal);
    signal(SIGPIPE, SIG_IGN); // don't die if a client vanishes mid-send

    Database db("patient_monitor.db");
    AlertEngine alert_engine(db, g_state);

    // Start the worker pool.
    std::vector<std::thread> workers;
    for (int i = 0; i < NUM_WORKERS; i++) {
        workers.emplace_back(worker_loop, i, std::ref(db), std::ref(alert_engine));
    }

    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    int opt = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_fd, (sockaddr*)&address, sizeof(address)) < 0) {
        perror("bind failed");
        return 1;
    }
    if (listen(server_fd, 16) < 0) {
        perror("listen failed");
        return 1;
    }

    std::cout << "Patient monitor server listening on port " << PORT << " with "
              << NUM_WORKERS << " workers...\n";

    std::vector<std::thread> client_threads;
    while (g_running) {
        sockaddr_in client_addr{};
        socklen_t client_len = sizeof(client_addr);
        int client_fd = accept(server_fd, (sockaddr*)&client_addr, &client_len);
        if (client_fd < 0) {
            if (!g_running) break; // accept() interrupted by shutdown
            continue;
        }
        client_threads.emplace_back(client_handler, client_fd, client_addr);
    }

    std::cout << "\nShutting down...\n";
    close(server_fd);
    for (auto& t : client_threads) if (t.joinable()) t.join();
    for (auto& t : workers) if (t.joinable()) t.join();
    return 0;
}
